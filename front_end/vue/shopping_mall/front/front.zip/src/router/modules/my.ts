
const my = {
	path: '/my',
	name: '我的',
	component: () => import('@/views/my/my.vue'),
	meta: {
		title: '我的',
		grade: 1
	}
};

export default my;