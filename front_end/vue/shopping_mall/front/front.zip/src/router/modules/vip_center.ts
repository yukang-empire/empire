
const vip_center = {
	path: '/vip_center',
	name: '会员中心',
	component: () => import('../../views/my/vip_center.vue'),
	meta: {
		title: '会员中心',
		grade: 2
	}
};

export default vip_center;