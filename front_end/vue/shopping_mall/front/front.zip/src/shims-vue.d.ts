declare module "*.vue" {
  import Vue from "vue";
  export default Vue;
}

declare module 'vue-awesome-swiper' {
	export const Swiper: any
	export const SwiperSlide: any
}
