<template>
	<div class="home">
		
	</div>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator';

@Component({
	components: {

	}
})

export default class home extends Vue{
	private data: any = {

	};

	created () {

	};
	mounted () {

	};

	
}
</script>

<style lang="scss" scoped>
	
</style>